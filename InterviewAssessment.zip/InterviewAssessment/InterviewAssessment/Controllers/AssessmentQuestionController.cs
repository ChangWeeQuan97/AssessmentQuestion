﻿using InterviewAssessment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace InterviewAssessment.Controllers
{
    public class AssessmentQuestionController : Controller
    {
        public static List<UserTable> Users = new List<UserTable>() {
                new UserTable(){ Id = 1,   user="Bill" ,          phone="0112137747",   checkin=new DateTime(2021, 1, 10, 16, 10, 50)},
                new UserTable(){ Id = 2,   user="Steve",          phone="0122136038",   checkin=new DateTime(2021, 2, 11, 15, 39, 50)},
                new UserTable(){ Id = 3,   user="Ram",            phone="0132130123",   checkin=new DateTime(2021, 3, 12, 11, 10, 50)},
                new UserTable(){ Id = 4,   user="Nicholas",       phone="0142137831",   checkin=new DateTime(2021, 4, 13, 12, 30, 50)},
                new UserTable(){ Id = 5,   user="Ginny",          phone="0152137213",   checkin=new DateTime(2021, 5, 14, 11, 11, 50)},
                new UserTable(){ Id = 6,   user="Qin Teck",       phone="0162133134",   checkin=new DateTime(2021, 6, 15, 13, 00, 50)},
                new UserTable(){ Id = 7,   user="Win Chuan",      phone="0172131321",   checkin=new DateTime(2021, 7, 16, 18, 10, 50)},
                new UserTable(){ Id = 8,   user="Kira",           phone="0182138213",   checkin=new DateTime(2021, 8, 17, 08, 10, 50)},
                new UserTable(){ Id = 9,   user="Kim Siong",      phone="0192133311",   checkin=new DateTime(2021, 5, 18, 12, 00, 50)},
                new UserTable(){ Id = 10,  user="Shaw Zhe",       phone="0112132131",   checkin=new DateTime(2021, 1, 19, 12, 10, 50)},
                new UserTable(){ Id = 11,  user="Zhi Yen",        phone="0161236823",   checkin=new DateTime(2021, 2, 20, 11, 59, 50)},
                new UserTable(){ Id = 12,  user="Ching Keat",     phone="0132131346",   checkin=new DateTime(2021, 3, 21, 12, 30, 50)},
                new UserTable(){ Id = 13,  user="Marcus",         phone="0158331113",   checkin=new DateTime(2021, 4, 22, 11, 59, 05)},
                new UserTable(){ Id = 14,  user="Michael",        phone="0152138109",   checkin=new DateTime(2021, 5, 23, 12, 10, 05)},
                new UserTable(){ Id = 15,  user="John",           phone="0168231113",   checkin=new DateTime(2021, 6, 24, 12, 00, 00)},
                new UserTable(){ Id = 16,  user="Tarun",          phone="0172139101",   checkin=new DateTime(2021, 7, 25, 08, 10, 38)},
                new UserTable(){ Id = 17,  user="Hina",           phone="0112731113",   checkin=new DateTime(2021, 8, 26, 18, 10, 11)},
                new UserTable(){ Id = 18,  user="Sambit",         phone="0192131912",   checkin=new DateTime(2021, 3, 11, 12, 30, 50)},
                new UserTable(){ Id = 19,  user="Anurag",         phone="0172331113",   checkin=new DateTime(2021, 1, 10, 13, 00, 05)},
                new UserTable(){ Id = 20,  user="Priyanka",       phone="0122131113",   checkin=new DateTime(2021, 2, 11, 11, 11, 35)},
                new UserTable(){ Id = 21,  user="Pranaya",        phone="0132132743",   checkin=new DateTime(2021, 3, 12, 11, 10, 18)},
                new UserTable(){ Id = 22,  user="Jasmine Lau",    phone="0191231113",   checkin=new DateTime(2021, 4, 13, 15, 39, 59)},
                new UserTable(){ Id = 23,  user="Kong Kah Yan",   phone="0152136439",   checkin=new DateTime(2021, 5, 14, 16, 10, 05)},
                new UserTable(){ Id = 24,  user="Jayden Lee",     phone="0111931113",   checkin=new DateTime(2021, 6, 15, 11, 10, 01)},
                new UserTable(){ Id = 25,  user="Yong Weng Kai",  phone="0172131233",   checkin=new DateTime(2019, 7, 16, 12, 20, 05)},
                new UserTable(){ Id = 26,  user="Low Jun Wei",    phone="0182131113",   checkin=new DateTime(2021, 8, 17, 13, 30, 10)},
                new UserTable(){ Id = 27,  user="Lim Kok Lin",    phone="0162831113",   checkin=new DateTime(2021, 6, 18, 14, 40, 15)},
                new UserTable(){ Id = 28,  user="Khaw Tong Lin",  phone="0112139190",   checkin=new DateTime(2021, 1, 19, 15, 50, 20)},
                new UserTable(){ Id = 29,  user="Lee Saw Loy",    phone="0167831113",   checkin=new DateTime(2021, 2, 20, 16, 52, 25)},
                new UserTable(){ Id = 30,  user="Chan Saw Lin",   phone="0132133239",   checkin=new DateTime(2020, 3, 21, 17, 55, 30)},
            };

        
        
       
        public ActionResult UserList()
        {
            return View();
        }
        public ActionResult LoadUserTableData()
        {
            return Json(Users.OrderByDescending(x => x.checkin), JsonRequestBehavior.AllowGet);
        }
        public ActionResult BacktoOriginalData()
        {
            var newlist = Users.Select(x => new { Id = x.Id, user=x.user, phone=x.phone , checkin=x.checkin}).Distinct().ToList();
            return Json(newlist.OrderByDescending(x => x.checkin), JsonRequestBehavior.AllowGet);
        }
        public ActionResult AddRandomData()
        {
            Random random = new Random();
            var testing= Users.OrderByDescending(x => random.Next()).Take(5).ToList();
            var test=Users.Select(v => new { v, i = random.Next() }).OrderByDescending(x => x.i).Take(5).Select(x => x.v);
            Users.AddRange(testing);
            return Json(Users.OrderByDescending(x => x.checkin), JsonRequestBehavior.AllowGet);
        }
    }
}