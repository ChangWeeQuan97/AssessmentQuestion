﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InterviewAssessment.Models
{
    public class UserTable
    {
        public int Id { get; set; }
        public string user { get; set; }
        public string phone { get; set; }
        public DateTime checkin { get; set; }
    }
}